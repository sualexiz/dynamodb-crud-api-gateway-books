# DynamoDB CRUD API usando API Gateway y AWS Lambda
 Prueba técnica

